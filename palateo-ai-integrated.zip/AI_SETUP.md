# Palateo AI guide setup

The app's AI guide supports Google Gemini through Google AI Studio and Claude through Anthropic. Calls go through the Vercel function at `/api/ai-guide`; provider secrets are read only from Vercel server environment variables and are never requested in the browser.

## Vercel environment variables

In the Vercel project that serves `palateocloudflarepages.vercel.app`, open **Settings → Environment Variables** and add these names for **Production** (and Preview/Development if desired):

| Name | Value |
| --- | --- |
| `GEMINI_API_KEY` | API key created in Google AI Studio |
| `ANTHROPIC_API_KEY` | API key created in the Anthropic Console |
| `SUPABASE_URL` | `https://ntuaqcnbhqtbhbnnobmm.supabase.co` |
| `SUPABASE_PUBLISHABLE_KEY` | This project's Supabase `sb_publishable_…` key |

Save the variables, then redeploy the Vercel project so the function receives them. Do not prefix provider secrets with `NEXT_PUBLIC_` or `VITE_`, and do not put provider keys in `index.html`, a public repository, or a browser form.

Users must sign in before calling the endpoint. The function verifies the Supabase access token, accepts only same-origin requests, limits message sizes/history and applies a best-effort per-instance request limit. Keep provider quotas and spending alerts enabled at each provider; serverless in-memory limits are not a substitute for provider-side quotas.

## Local development

Run this folder with Vercel's local development server after installing/logging in to the Vercel CLI, and provide the four variables in a local `.env.local` file. `.env*` files are ignored by Git. Never commit real values.

When a user sends a message, the app sends the question, selected city and a short list of venue names/areas/cuisines/ratings/prices to the selected provider. Saved taste answers, including dietary preferences, are sent only if the user checks the per-message opt-in box. It does not send profile name, phone, email, saved venues or authentication tokens to either model provider. The access token goes only to Palateo's same-origin endpoint for Supabase verification.
